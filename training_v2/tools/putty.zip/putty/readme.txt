中文描述：
1.解压putty.rar
2.插上模块的USB数据线
3.进入putty目录，双击puttyadb.bat文件



English:
1. Unzip the putty.rar
2. Plug in the USB data cable of the module
3. Go to putty directory and double-click the puttyadb.bat